import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empelados',
  templateUrl: './empelados.component.html',
  styleUrls: ['./empelados.component.sass']
})
export class EmpeladosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
