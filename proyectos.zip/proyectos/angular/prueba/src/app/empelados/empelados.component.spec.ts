import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpeladosComponent } from './empelados.component';

describe('EmpeladosComponent', () => {
  let component: EmpeladosComponent;
  let fixture: ComponentFixture<EmpeladosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpeladosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpeladosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
