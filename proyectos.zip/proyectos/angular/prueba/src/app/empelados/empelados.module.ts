import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmpeladosRoutingModule } from './empelados-routing.module';
import { EmpeladosComponent } from './empelados.component';

import { FormsModule } from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    EmpeladosRoutingModule,
    FormsModule
  ]
})
export class EmpeladosModule {
  header = 'Empleados';
  description = 'Manage your contact list';
  numberOfContacts = 0;
  counterStyleColor = 'green';
  counterClass = 'warning';
  formHidden = false;
}
