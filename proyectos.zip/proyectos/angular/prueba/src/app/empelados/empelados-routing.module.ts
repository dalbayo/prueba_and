import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EmpeladosComponent } from './empelados.component';

const routes: Routes = [{ path: '', component: EmpeladosComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmpeladosRoutingModule { }
