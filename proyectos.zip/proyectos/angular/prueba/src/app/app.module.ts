import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpHeaders} from '@angular/common/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(public http: HttpClient) {

    this.getEmpleados().subscribe(
      datos => {
        this.tabledata = datos;
        this.empleados = this.tabledata;
      }, error => {

      }
    );

  }

  tabledata: any;
  empleados = [];

  getEmpleados() {
    const parametros = { };
    const requestOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: parametros
    };
    return this.http.get('http://localhost:9090/empleado/getEmpleados', requestOptions);
  }
  guardaEmpleados(empelados) {
      const requestOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
      };
      return this.http.post('http://localhost:9090/empleado/guardaEmpleados', {
        empelados
      }, requestOptions);
    }
  getEmpleadoId(id) {
    const parametros = { id };
    const requestOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: parametros
    };
    return this.http.get('http://localhost:9090/empleado/getEmpleadoId', requestOptions);
  }
  getEliminaEmpleadoId(id) {
    const parametros = {id};
    const requestOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: parametros
    };
    return this.http.get('http://localhost:9090/empleado/getEliminaEmpleadoId', requestOptions);
  }
}
